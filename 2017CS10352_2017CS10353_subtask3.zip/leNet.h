#include <vector>

int leNetArchitecture(std::vector<std::vector<float> > &img, char* c1, char* c2, char* fc1, char* fc2, std::vector<float> &prob);