#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <list>
#include <algorithm>
#include <iterator>
#include <cmath>
#include <bitset>
#include <numeric>
#include <stdexcept>
#include <iomanip>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <chrono>
#include <map>

using namespace std;
